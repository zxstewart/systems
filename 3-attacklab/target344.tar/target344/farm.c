/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_333()
{
    return 3281016941U;
}

unsigned getval_163()
{
    return 2425394264U;
}

unsigned addval_409(unsigned x)
{
    return x + 3624397325U;
}

unsigned getval_231()
{
    return 3281031256U;
}

unsigned getval_215()
{
    return 2496104776U;
}

void setval_375(unsigned *p)
{
    *p = 3347662926U;
}

void setval_296(unsigned *p)
{
    *p = 3267856712U;
}

unsigned getval_171()
{
    return 3347662979U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_110(unsigned *p)
{
    *p = 3222847881U;
}

unsigned getval_447()
{
    return 3269495112U;
}

void setval_159(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_462()
{
    return 3229928073U;
}

void setval_309(unsigned *p)
{
    *p = 3284831022U;
}

unsigned getval_369()
{
    return 2428619095U;
}

void setval_460(unsigned *p)
{
    *p = 3268839871U;
}

unsigned addval_433(unsigned x)
{
    return x + 3284248965U;
}

void setval_290(unsigned *p)
{
    *p = 3678983817U;
}

unsigned addval_106(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_419()
{
    return 3286272328U;
}

unsigned getval_454()
{
    return 3223372233U;
}

unsigned getval_391()
{
    return 3531915657U;
}

unsigned addval_204(unsigned x)
{
    return x + 3526416009U;
}

void setval_224(unsigned *p)
{
    *p = 3527985801U;
}

unsigned addval_116(unsigned x)
{
    return x + 3223372169U;
}

unsigned addval_367(unsigned x)
{
    return x + 3380923021U;
}

unsigned getval_167()
{
    return 3286239560U;
}

unsigned addval_479(unsigned x)
{
    return x + 3229931145U;
}

unsigned getval_440()
{
    return 3252717896U;
}

unsigned getval_210()
{
    return 3372799657U;
}

void setval_257(unsigned *p)
{
    *p = 3525888649U;
}

unsigned addval_478(unsigned x)
{
    return x + 1807996557U;
}

unsigned getval_259()
{
    return 3286272332U;
}

unsigned addval_117(unsigned x)
{
    return x + 3264268937U;
}

unsigned addval_119(unsigned x)
{
    return x + 3526937225U;
}

void setval_385(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_288(unsigned x)
{
    return x + 3599366736U;
}

unsigned addval_222(unsigned x)
{
    return x + 3284208113U;
}

void setval_165(unsigned *p)
{
    *p = 3389620393U;
}

unsigned addval_214(unsigned x)
{
    return x + 3380926105U;
}

void setval_315(unsigned *p)
{
    *p = 3674784201U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
